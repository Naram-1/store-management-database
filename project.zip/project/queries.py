import mysql.connector

def connect_db():
    return mysql.connector.connect(
        host="127.0.0.1",
        user="root",
        password="Hej123321",
        database="store_management"
    )


# Query 1 - Orders with customer info
def show_orders_with_customers():
    conn = connect_db()
    cursor = conn.cursor(buffered=True)

    query = """
    SELECT Orders.order_id, Customers.name, Orders.order_date, Orders.status
    FROM Orders
    JOIN Customers ON Orders.customer_id = Customers.customer_id;
    """

    cursor.execute(query)

    print("\nOrder ID | Customer Name        | Date       | Status")
    print("-" * 60)
    for order_id, name, date, status in cursor.fetchall():
        print(f"{order_id:<8} | {name:<20} | {date} | {status}")

    conn.close()


# Query 2 - Products inside each order
def show_order_products():
    conn = connect_db()
    cursor = conn.cursor(buffered=True)

    query = """
    SELECT Orders.order_id, Products.name, OrderItems.quantity, OrderItems.unit_price
    FROM OrderItems
    JOIN Orders ON OrderItems.order_id = Orders.order_id
    JOIN Products ON OrderItems.product_id = Products.product_id;
    """

    cursor.execute(query)

    print("\nOrder ID | Product Name              | Qty | Unit Price")
    print("-" * 60)
    for order_id, product, qty, price in cursor.fetchall():
        print(f"{order_id:<8} | {product:<25} | {qty:<3} | {price}")

    conn.close()


# Query 3 - Best selling products
def best_selling_products():
    conn = connect_db()
    cursor = conn.cursor(buffered=True)

    query = """
    SELECT Products.name, SUM(OrderItems.quantity) AS total_sold
    FROM OrderItems
    JOIN Products ON OrderItems.product_id = Products.product_id
    GROUP BY Products.name
    ORDER BY total_sold DESC;
    """

    cursor.execute(query)

    print("\nProduct Name                 | Total Sold")
    print("-" * 40)
    for name, total in cursor.fetchall():
        print(f"{name:<28} | {total}")

    conn.close()


# Query 4 - Total sales revenue
def total_sales_revenue():
    conn = connect_db()
    cursor = conn.cursor(buffered=True)

    query = """
    SELECT SUM(quantity * unit_price) AS total_sales
    FROM OrderItems;
    """

    cursor.execute(query)

    result = cursor.fetchone()
    total_sales = result[0] if result[0] is not None else 0

    print("\nTotal Sales Revenue: {:.2f} SEK".format(total_sales))

    conn.close()


# Query 5 - Low stock products
def low_stock_products():
    conn = connect_db()
    cursor = conn.cursor(buffered=True)

    query = """
    SELECT name, stock_quantity
    FROM Products
    WHERE stock_quantity < 10;
    """

    cursor.execute(query)

    print("\nProduct Name                 | Stock")
    print("-" * 40)
    for name, stock in cursor.fetchall():
        print(f"{name:<28} | {stock}")

    conn.close()